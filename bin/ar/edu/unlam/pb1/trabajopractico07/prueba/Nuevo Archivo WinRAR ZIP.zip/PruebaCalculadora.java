package ar.edu.unlam.pb1.trabajopractico07.prueba;

import ar.edu.unlam.pb1.trabajopractico07.dominio.Calculadora;

public class PruebaCalculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculadora prueba= new Calculadora();
		System.out.println(prueba.factorial(6));
	}

}
